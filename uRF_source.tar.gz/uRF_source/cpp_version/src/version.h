#ifndef RANGER_VERSION
#define RANGER_VERSION "0.15.3"
#endif
